﻿using System;
using System.Security.Policy;
using static ObjectClasses;

public static class ObjectClasses
{
    #region Classes and Objects
    //public static void Run()
    //{
    //    Book b1 = new Book();
    //    b1.title = "Kaif";
    //    b1.SetPrice(150);
    //    b1.MyBook();
    //}

    //// Book class can be nested or placed in a separate file
    //private class Book
    //{
    //    public string title;
    //    private int price;

    //    public void SetPrice(int a)
    //    {
    //        price = a;
    //    }

    //    public void MyBook()
    //    {
    //        Console.WriteLine($"The book title is {title} and the price of the book is {price}");
    //    }
    //}


    //public class Employee
    //{
    //    public string Name;
    //    private int Salary;
    //    protected int EmployeeID;

    //    public void SetSalary(int salary)
    //    {
    //    Salary = salary;
    //    }


    //    public void ShowSalary()
    //    {
    //        Console.WriteLine($"The salary of the Employee is {Salary}");
    //    }

    //    public void ShowEmp()
    //    {
    //        Console.WriteLine($"The Employee Name is {Name} and his employee id is {EmployeeID}");
    //    }
    //}

    //public class Manager :Employee
    //{
    //   public void setManagerDetails()
    //    {
    //        EmployeeID = 101;
    //        Name="Shaikh";
    //    }

    //}

    //public static void Run2()
    //{
    //    Employee employee = new Employee();
    //    Manager M = new Manager();
    //    M.SetSalary(150000);
    //    M.setManagerDetails();
    //    M.ShowEmp();
    //    M.ShowSalary();

    //}


    //public class BankAccount
    //{
    //    private int balance;

    //    public void Deposit(int depamount)
    //    {
    //        balance = depamount;
    //    }

    //    public void DepositedAmount()
    //    {
    //        Console.WriteLine($"Deposited: {balance}");
    //    }
    //    public void CurrentBalance()
    //    {
    //        Console.WriteLine($"Current Balance: {balance}");
    //    }
    //}

    //public static void Run3()
    //{
    //   BankAccount bankAccount = new BankAccount();
    //    bankAccount.Deposit(15000);
    //    bankAccount.DepositedAmount();
    //    bankAccount.CurrentBalance();
    //}


    #endregion

    //#region Constructor
    //class Employee
    //{
    //    public string name;
    //    public int salary;

    //    public Employee()
    //    {
    //        name = "Not Assigned";
    //        salary = 0;
    //    }

    //    public Employee(string Name,int Salary)
    //    {
    //        name = Name;
    //        salary = Salary;
    //    }

    //    public Employee(string Name)
    //    {
    //        name = Name;
    //        salary = 10000;
    //    }

    //    public void ShowDetails()
    //    {
    //        Console.WriteLine($"Name : {name} \n Salary : {salary}");
    //    }
    //}

    //public static void Run4() { 
    //Employee emp1 = new Employee();
    //    emp1.ShowDetails();
    //    Employee emp2 = new Employee("Kaif",15000);
    //    emp2.ShowDetails();
    //    Employee emp3 = new Employee("Shaikh");
    //    emp3.ShowDetails(); 

    //}

    //#endregion

    #region Inheritance

    //Single Inheritance

    class Shape
    {
        public void DisplayShapeType()
        {
            Console.WriteLine("This is a Circle");
        }
    }

    class Circle : Shape
    {
        public void CalculateArea(double area)
        {
            double Circlearea = area * area;
            Console.WriteLine($"Area:{Circlearea}");
        }
    }


    public static void Run5()
    {
        Circle circle = new Circle();
        circle.DisplayShapeType();
        circle.CalculateArea(15.2);
    }


    //Multilevel 

    class LivingBeing
    {
        public void Breath()
        {
            Console.WriteLine("I can Breath");
        }
    }

    class Animal : LivingBeing
    {
        public void Walk()
        {
            Console.WriteLine("I can Walk");
        }
    }

    class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("I can Bark");
        }
    }

    public static void Run6()
    {
        Dog d = new Dog();
        d.Breath();
        d.Walk();
        d.Bark();
    }

    interface IDrawable
    {
        void Draw();
    }

    interface IPaint
    {
        void Paint(string colour);
    }

    class A : IDrawable, IPaint
    {
        public void Draw()
        {
            Console.WriteLine("I can Draw");
        }

        public void Paint(string black)
        {
            Console.WriteLine($"I can colour with {black}");
        }
    }

    public static void Run7()
    {
        A a = new A();
        a.Draw();
        a.Paint("bhjfb");
    }
    #endregion

    #region

    //Polymorphism Method Overloading

    class MathUtility
    {
        public void Multiply(int num1, int num2)
        {
            Console.WriteLine($"Int Multiply :{num1 * num2}");
        }
        public void Multiply(double num1, double num2)
        {
            Console.WriteLine($"Double Multiply :{num1 * num2}");
        }

        public void Multiply(int num1, int num2, int num3)
        {
            Console.WriteLine($"Three Int Multiply :{num1 * num2 * num3}");
        }
    }

    public static void Run8()
    {
        MathUtility math = new MathUtility();
        math.Multiply(1, 3);
        math.Multiply(2.5, 4.5);
        math.Multiply(2, 2, 5);
    }

    //Polymorphism Method Overriding

    class Employee
    {
        public virtual void CalculateSalary()
        {
            Console.WriteLine("Employee earns 80000 salary");
        }
    }

    class Manager : Employee
    {

        public override void CalculateSalary()
        {
            Console.WriteLine("Manager earns 80000 salary");
        }
    }

    public static void Run10()
    {
        Employee employee = new Manager();
        employee.CalculateSalary();

    }


    class Printer
    {
        public virtual void Print()
        {
            Console.WriteLine("Printing ...");
        }

        public void Print(string documentName)
        {
            Console.WriteLine($"Printing document: {documentName}");
        }
    }

    class ColorPrinter : Printer

    {
        public override void Print()
        {
            Console.WriteLine("Printing in color");
        }
    }


    public static void Run11()
    {
        Printer printer = new ColorPrinter();
        printer.Print();
        printer.Print("MyDOC.pdf");
    }

    #endregion

    #region Encapsulation


    class Emploi
    {

        private string name;
        private int salary;

        public void SetDetails(string name, int salary)
        {
            this.name = name;
            if (salary > 0)
            {
                this.salary = salary;
            }
            else
            {
                this.salary = 0;
            }
        }

        public void ShowDetails()
        {
            Console.WriteLine($"The salary of the {name} is {salary}");
        }

    }

    public static void Run13()
    {

        Emploi emploi = new Emploi();
        emploi.SetDetails("Kaif", 50000);
        emploi.ShowDetails();
    }
    #endregion


    #region Abstract

    abstract class AShape
    {
        public abstract void CalculateArea(int r);

        public void DisplayShapeType()
        {
            Console.WriteLine("This is a shape");
        }
    }

    class ACircle : AShape
    {
        public override void CalculateArea(int r)
        {
            Console.WriteLine($"The Area of the Circle is : {3.14 * r * r} ");
        }

    }

    public static void Run15()
    {
        AShape shape = new ACircle();
        shape.CalculateArea(15);
        shape.DisplayShapeType();
    }


    abstract class AEmployee
    {
        public abstract void CalculateSalary();

        public void PrintWelcome()
        {
            Console.WriteLine("Welcome Employee");
        }
    }


    class FullTimeEmployee : AEmployee
    {
        public override void CalculateSalary()
        {
            Console.WriteLine("Full-Time Salary: 50000\r\n");
        }
    }

    class PartTimeEmployee : AEmployee
    {
        public override void CalculateSalary()
        {
            Console.WriteLine("Full-Time Salary: 20000\r\n");
        }
    }

    public static void Run14()
    {
        AEmployee employee1 = new FullTimeEmployee();
        AEmployee employee2 = new PartTimeEmployee();


        employee1.PrintWelcome();
        employee1.CalculateSalary();

        employee2.PrintWelcome();
        employee2.CalculateSalary();
    }

    abstract class Device
    {
        public abstract void StartDevice();

        public Device()
        {
            Console.WriteLine("Device created");
        }
    }

    class Mobile : Device
    {
        public override void StartDevice()
        {
            Console.WriteLine("Mobile is starting...");
        }
    }

    public static void Run16()
    {
        Device device = new Mobile();
        device.StartDevice();

    }

    #endregion

    #region Interfaces
    interface IVehicle
    {
        void Start();
        void Stop();
    }

    class Bike : IVehicle
    {
        public void Start()
        {
            Console.WriteLine("Bike is starting...");

        }
        public void Stop()
        {
            Console.WriteLine("Bike is stopping...");
        }
    }

    public static void Run17()
    {
        IVehicle vehicle = new Bike();
        vehicle.Start();
        vehicle.Stop();
    }

    interface IEngine
    {
        void StartEngine();
    }

    interface IVehicle2 : IEngine
    {
        void Drive();
    }

    class Car : IVehicle2
    {
        public void StartEngine()
        {
            Console.WriteLine("Engine started...");
        }
        public void Drive()
        {
            Console.WriteLine("Car is driving...");
        }
    }
    public static void Run20()
    {
        IVehicle2 car = new Car();
        car.StartEngine();
        car.Drive();
    }

    interface ICamera
    {
        void TakePhoto();
    }

    interface IMusicPlayer
    {
        void PlayMusic();
    }


    class SmartPhone : ICamera, IMusicPlayer
    {
        public void TakePhoto()
        {
            Console.WriteLine("Photo taken!");
        }
        public void PlayMusic()
        {
            Console.WriteLine("Playing music...");
        }
    }


    public static void Run21()
    {
        SmartPhone smartPhone = new SmartPhone();
        smartPhone.TakePhoto();
        smartPhone.PlayMusic();
    }
    #endregion


    #region this and base keyword

    class Vehicle
    {
        public string type = "Vehicle";

        public virtual void Show()
        {
            Console.WriteLine($"I am a {this.type}");
        }
    }

    class Truck : Vehicle
    {
        string type = "Truck";
        public override void Show()
        {
            base.Show();
            Console.WriteLine($"I am a {this.type}");
            Console.WriteLine($"Base type: {base.type}");
            Console.WriteLine($"Derived type: {this.type}");
        }

    }


    public static void Run25()
    {
        Truck truck = new Truck();  
        truck.Show();

    }

    #endregion


    class Student
    {
        static int totalStudents;
        public string name;

        public Student (string name)
        {
            this.name= name;
        }
        public void Show()
        {
            Console.WriteLine($"My Name is {name}");
            totalStudents++;
        }

        public static void ShowCount()
        {
            Console.WriteLine($"Total Students is :{totalStudents}");
        }


    }

    public static void Run256()
    {
        Student s1 = new Student("Kaif");
        Student s2 = new Student("Sana");
        s1.Show();
        s2.Show();
        Student.ShowCount();
    }
}
