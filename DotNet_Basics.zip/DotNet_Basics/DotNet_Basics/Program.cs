﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DotNet_Basics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Control Basics

            //EvenOrOdd();
            //PosOrNeg();
            //AcceptAge()
            //SwitchProg();
            //ForLoopProg();
            //Fact();
            //ForRStar();
            //ForIStar();
            //ForISStar();
            //ForEStar();
            //WhileRStar();
            //WhileIStar();
            // WhileLStar();
            //WhileEStar();
            //While1to10();
            //WhileEven();
            //WhileSum();
            //DoWhileProg();

            //------ Till Here

            //ref
            //int x = 10;
            //Ref1(ref x);

            //int y = 5;
            //Swap(ref x, ref y);

            //int a = 11;
            //AddRef(ref a);

            //string str = "Kaif";
            //StringRef(ref str);

            //int[] newarr = {1,2,3,4,5 };
            //Update(ref newarr);
            //Console.WriteLine(newarr);


            //---Till here

            //out
            //string NewName;
            //int NewAge;
            //GetStudents(out NewName, out NewAge);
            //Console.WriteLine($"New Name :  { NewName}, New Age : {NewAge}");
            ////Console.WriteLine("New Age :", NewAge);
            ///

            //params
            //Print(1, 2, 2, 54, 45, 5);
            //Console.WriteLine("New");
            //Print(2,25,5);

            //--Till Here

            //Method Overloading
            //Kaif("Kaif");
            //Kaif();
            //Kaif(21);

            //

            //Recursion

            //Console.Write("Please enter a number : ");
            //int  n=Convert.ToInt32(Console.ReadLine());
            //Console.Write("Please enter a power : ");
            //int p = Convert.ToInt32(Console.ReadLine());
            //PowerRec(n, p);
            ////FactRec(n);
            ////Console.WriteLine($"The factorial of number {n} is {FactRec(n)}");
            ////SumRec(n);
            //Console.WriteLine($"The power of number {n} is {PowerRec(n,p)}");


            //exception handling
            //Divide(20,10);
            //Divide(6, 0);
            //BalanceChecker(150000);
            //RunBalanceChecker();
            //int[] num = {1,2,5,74,4,10,6,50,21,59 };
            //PrintEven(num);

            //int[] arr = { 5, 8, 1, 3, 1, 5 };
            //PrintSecondSmallest(arr);
            //SumRows();
            //JaggedArray();
            SumColumns();

        }

        #region Control Basics

        #region if, else if, else Questions:
        //Check if a number is even or odd.
        static void EvenOrOdd()
        {
            Console.Write("Enter number :");
            int num =Convert.ToInt32(Console.ReadLine());

            if (num % 2 == 0)
            {
                Console.WriteLine("The number "+num+" is even");
            }
            else
            {
                {
                    Console.WriteLine("The number " + num + " is odd");
                }
            }
        }

        //Check if a number is positive, negative, or zero.
        static void PosOrNeg()
        {
            Console.Write("Enter number :");
            int num = Convert.ToInt32(Console.ReadLine());

            if (num > 0)
            {
                Console.WriteLine("The number "+num+" is positive");
            }
            else if (num<0)
            {
                Console.WriteLine("The number " + num + " is negative");
            }
            else
            {
                Console.WriteLine("The number is zero");
            }

        }

        //Accept age and print category:
        static void AcceptAge()
        {
            Console.Write("Please Enter Age: ");
            int age= Convert.ToInt32(Console.ReadLine());
            if (age < 13)
            {
                Console.WriteLine("Child");
            }
            else if (age >= 13 && age <= 19)
            {
                Console.WriteLine("Teen"); 
            }
            else if (age >=20 && age <=59)
            {
                Console.WriteLine("Adult");
            }
            else
            {
                Console.WriteLine("Senior");
            }
        }
        #endregion

        #region Switch


        public void SwitchProg()
        {
            Console.Write("Please enter the Day :");
            int day= Convert.ToInt32(Console.ReadLine());

            switch(day)
            {
                case 1:Console.WriteLine("The day is Monday");break;    
                    case 2:Console.WriteLine("The day is Tuesday"); break;
                    case 3:Console.WriteLine("The day is Wednesday");break;
                case 4:Console.WriteLine("The day is Thursday");break;
                case 5: Console.WriteLine("The day is Friday"); break;
                case 6: Console.WriteLine("The day is Saturday"); break;
                case 7: Console.WriteLine("The day is Sunday"); break;

            }
        }

        #endregion

        #region For Loop

        static void ForLoopProg()
        {
            for (int i = 1; i < 50; i+= 2)
            {
                Console.WriteLine(i);
            }
        }

        static void Fact()
        {
            Console.Write("Please enter a number : ");
            int number =Convert.ToInt32(Console.ReadLine());

            int fact = 1;

            for (int i = 1; i <= number; i++)
            {
                fact *= i;
            }

            Console.WriteLine($"The factorial of {number} is {fact}");
            
        
        }

        #endregion

        #region


        static void While1to10()
        {
            int i = 1;

            while(i<11)
            {

                Console.WriteLine(i);
                i++;
            }


        }


        static void WhileEven()
        {
            int i = 1;
            while (i < 100)
            {
                if (i % 2 != 0)
                {
                    i++;
                    continue;
                }
              
                    Console.WriteLine(i);
              
                i++;
            }
        }

        static void WhileSum()
        {
            Console.Write("Please enter the number: ");
            int num = Convert.ToInt32(Console.ReadLine());

            while (num != 0)
            {
                Console.Write("Please enter the number: ");
                int num2 = Convert.ToInt32(Console.ReadLine());

                if (num2 == 0) 
                    break;
                num += num2;

            }

            Console.WriteLine($"The sum of all numbers is {num}");
        }
        #endregion

        #region Do While Loops
        static void DoWhileProg()
        {
            string pass = "";
            do
            {
                Console.Write("Please enter the password :");
                pass = Console.ReadLine();
            }
            while (pass != "admin123");

        }

        #endregion

        #region For Loop Star Patterns

        static void ForRStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }

        static void ForIStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());
            for (int i = rows; i >= 1; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
        static void ForISStar()
        {
            Console.Write("Please enter rows");
            int rows = Convert.ToInt32(Console.ReadLine());


            for (int i=1;i<=rows;i++)
            {
                for (int j = rows; j >=i; j--)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

        }

        static void ForLStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= rows; i++) {

                for (int space=1;space <=rows-i;space++) {
                    Console.Write(" ");
                }
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();
            }
        }

        static void ForEStar()
        {
            Console.Write("Please enter rows: ");
            int rows = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= rows; i++)
            {
                // Print leading spaces
                for (int space = 1; space <= rows - i; space++)
                {
                    Console.Write(" ");
                }

                // Print stars with a space in between to maintain triangle shape
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("* ");
                }

                Console.WriteLine();
            }
        }

        #endregion


        #region While Loops Star Pattern

        static void WhileRStar() {
            Console.Write("Please enter rows: ");
            int rows = Convert.ToInt32(Console.ReadLine());
            int i = 1;
            while (i <= rows)
            {
                int j = 1;
                while (j <= i) {
                    Console.Write("*");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }

        static void WhileIStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());
            int i = 1;

            while (i<=rows)
            {
                int j = rows;
                while (j>=i)
                {
                    Console.Write("*");
                    j--;
                }


                Console.WriteLine();
                i++;
            }
        
        
        }


        static void WhileLStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());

            int i = 1;
            while(i<=rows)
            {

                int space = 1;
                while (space<=(rows-i))
                {
                    Console.Write(" ");
                    space++;
                }
                int j = 1;
                while (j <= i)
                {
                    Console.Write("*");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }

        static void WhileEStar()
        {
            Console.Write("Please enter rows : ");
            int rows = Convert.ToInt32(Console.ReadLine());

            int i = 1;

            while (i <= rows)
            {
                int space = 1;
                while (space <= rows - i)
                {
                    Console.Write(" ");
                    space++;
                }
                int j = 1;
                while (j <= i)
                {
                    Console.Write("* ");
                    j++;
                }

                i++;
                Console.WriteLine();
            }
        }

        #endregion
        #endregion


        #region ref
        //Write a method that multiplies a number by 10 using ref.

        static void Ref1(ref int a)
        {
             a=a*10;
            Console.WriteLine(a);
        }
        //Create a method Swap(ref int a, ref int b) and test it in Main().
        static void Swap(ref int a,ref int b)
        {
            int temp;

            temp = b;
            b = a;

            a = temp;

            Console.WriteLine($"{a} , {b}");

        }
        //Write a method that receives an int by ref, and if it's odd, makes it even by adding 1.
        static void AddRef(ref int a)
        {
            if (a%2!=0)
            {
                a = a + 1;
            }
            Console.WriteLine(a);
        }
        //Pass a string using ref, and append " - Processed" to it inside the method.
        static void StringRef(ref string test)
        {

            Console.WriteLine(test + "- Processed");
        }

        //Pass an array to a method using ref and update all elements to 0.


        static void Update(ref int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = 0;
            }
        }
        #endregion

        #region out Keyword – Questions

        static void GetStudents(out string name,out int age)
        {
            name = "Kaif";
            age = 10;
        }

        #endregion


        #region Params

        static void Print(params int[] num)
        {
            for (int i=0;i<num.Length;i++)
            {

                Console.WriteLine(num[i]);  
            }

        }
        #endregion


        #region Method Overloading
        static void Kaif(string name)
        {
            Console.WriteLine($"My name is {name}");

        }

        static void Kaif()
        {
            Console.WriteLine("My Surname is Shaikh");
        }

        static void Kaif(int age)
        { 
        Console.WriteLine($"My age is {age}");
        }
        #endregion


        #region Recursion

        static int FactRec(int number)
        {
            if (number == 1)

                return 1;
            else
                return number *FactRec(number-1);
        }


        static int SumRec(int num)
        {
            if (num == 1)
                return 1;
            else 
                return num +SumRec(num-1);
        }
        #endregion

        static int PowerRec(int num, int power)
        {
            if (power == 1)
                return num;
            else
                return num * PowerRec(num, power - 1);
        }

        #region Exception Handling 

        //try catch finaly

        public static void Divide(int a,int b)
        {
            try {
                double result = a / b;
                Console.WriteLine($"The result of {a} divide by {b} is {result}");  
            
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("Cannot divide by 0");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Operation Executed Successfully");
            }
        }



        #endregion

        public static void BalanceChecker(int balance)
        {
            if (balance == 0)
            {
                throw new ZeroBalanaceExeption("The Account has Zero Balance");
            }
            else if (balance > 100000)
            {
                throw new MaxBalanaceExeption();
            }
            else if (balance < 50000)
            {
                throw new MinBalanaceExeption();
            }
            else
            { 
            Console.WriteLine("Your Current Balance is "+balance);
            
            }
         
        }


        public static void RunBalanceChecker()
        {
            try
            {

                BalanceChecker(150000);
            }
            catch (ZeroBalanaceExeption ex)
            {
                Console.WriteLine( ex.Message);
            }
            catch (MaxBalanaceExeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (MinBalanaceExeption ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("✅ Operation complete.");
            }
        }


        public static void PrintEven(int[] arr )
        {

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    Console.WriteLine($"The number {arr[i]} is even number at position {i}");
                }
            }
        }

        public static void PrintSecondSmallest(int[] num)
        {
            int smallest;
            int secondsmallest;
            for (int i = 0; i < num.Length; i++)
            {
                 smallest = num[i];

            
            }
        }
        public static void SumRows()
        {
            int[,] arr = { { 2,4,6},
                           { 1,3,5} };

            
            int sum2 = 0;

            for (int row = 0; row < arr.GetLength(0); row++)
            {
                int sum = 0;
                for (int col = 0; col < arr.GetLength(1); col++)
                {
                    sum += arr[row, col];
                }
                Console.WriteLine($"THe sum of {row + 1} row is "+sum);
            }
           
        }


        public static void JaggedArray()
        {
            int[][] jagged = new int[3][];  // 3 rows

            jagged[0] = new int[] { 1, 2, 3 };       // row 0: 3 elements
            jagged[1] = new int[] { 4, 5 };          // row 1: 2 elements
            jagged[2] = new int[] { 6, 7, 8, 9 };    // row 2: 4 elements


           

            for (int i = 0; i < jagged.Length; i++)
            {
                int sum = 0;
                for (int j = 0; j < jagged[i].Length; j++)
                {
                    sum += jagged[i][j];
                }
                Console.WriteLine($"The sum of the {i+1} row is "+sum);
            }

        }

        public static void SumColumns()
        {
            int[,] arr = { { 2,4,6},
                           { 1,3,5} };


            


            for (int col = 0; col < arr.GetLength(1); col++)
            {
                int sum2 = 0;
                for (int row = 0; row < arr.GetLength(0); row++)
                { 
                sum2 += arr[row, col];
                
                }
            Console.WriteLine($"The sum of {col+1} is {sum2}");
            }

        }

        public static void SumJaggedCol()
        {
            int[][] jagged = new int[3][];  // 3 rows

            jagged[0] = new int[] { 1, 2, 3 };       // row 0: 3 elements
            jagged[1] = new int[] { 4, 5 };          // row 1: 2 elements
            jagged[2] = new int[] { 6, 7, 8, 9 };    // r


        }
    }
}
