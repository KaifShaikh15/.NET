﻿using System;

class ZeroBalanaceExeption : Exception
{
    public ZeroBalanaceExeption(string message) : base(message) {}


}


class MaxBalanaceExeption : Exception
{
    public MaxBalanaceExeption() : base("The Account has More than 1 Lakh Balance") { }
}

class MinBalanaceExeption : Exception
{
    public MinBalanaceExeption() : base("The Account has less than 50,000 Balance") { }
}